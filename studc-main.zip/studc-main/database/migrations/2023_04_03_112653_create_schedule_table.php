<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('schedule', function (Blueprint $table) {
            $table->id();
            $table->string('lesson');
            $table->foreignId('type_id')->constrained('schedule_types');
            $table->integer('day_of_week');
            $table->string('time_of_the_lesson'); // TODO можно было бы сделать и рендж времени, ну ладно уже
            //TODO Возможно будут измениния в логики, типа нужно будет добавить группу на которой расписани или еще что.
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('schedule');
    }
};
