<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', static function (Blueprint $table) {
            $table->id();
            $table->string('title')->default('Внутренний перевод');
            $table->string('address')->comment('При выводе, кому отправилась, при пополнении, от кого пришло');
            $table->integer('amount');
            $table->boolean('type')->comment('0 - вывод, 1 - пополнение');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
