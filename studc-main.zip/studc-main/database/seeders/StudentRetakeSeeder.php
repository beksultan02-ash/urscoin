<?php

namespace Database\Seeders;

use App\Models\StudentRetake;
use Illuminate\Database\Seeder;

class StudentRetakeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
//        StudentRetake::factory(10)->create();

        $retakes = [
            [
                'title' => 'Веб-разработка',
                'payment_amount' => '1000',
                'expiration_date' => new \DateTime('2023-08-31 16:10:42'),
                'status' => 0,
                'user_id' => 1,
                'created_at' => '2023-05-11 16:10:42',
                'updated_at' => '2023-05-11 16:10:42'
            ],
            [
                'title' => 'Архитектура',
                'payment_amount' => '500',
                'expiration_date' => new \DateTime('2023-08-21 20:00:00'),
                'status' => 0,
                'user_id' => 1,
                'created_at' => '2023-05-11 16:10:42',
                'updated_at' => '2023-05-11 16:10:42'
            ]
        ];

        StudentRetake::insert($retakes);
    }
}
