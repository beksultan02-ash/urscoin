<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $products = [
            [
                'title' => 'Бутылка-термос с эмблемой IITU',
                'price' => 1000,
                'currency_id' => 1,
                'photo' => env('APP_URL'). ('/products/termosIITU.png') //TODO решить баг со storage, и переделать нормально
            ],
            [
                'title' => 'Бутылка-термос с эмблемой IITU',
                'price' => 1000,
                'currency_id' => 1,
                'photo' => env('APP_URL'). ('/products/termosIITU2.png')
            ],
            [
                'title' => 'Бутылка-термос с эмблемой IITU',
                'price' => 1000,
                'currency_id' => 1,
                'photo' => env('APP_URL'). ('/products/termosIITU3.png')
            ],
            [
                'title' => 'Бутылка-термос с эмблемой IITU',
                'price' => 1000,
                'currency_id' => 1,
                'photo' => env('APP_URL'). ('/products/termosIITU4.png')
            ],
            [
                'title' => 'Флешка 1ГБ с эмблемой IITU',
                'price' => 1000,
                'currency_id' => 1,
                'photo' => env('APP_URL'). ('/products/usbIITU.png')
            ],
        ];

        foreach ($products as &$product) {
            $product['created_at'] = now();
            $product['updated_at'] = now();
        }

        Product::insert($products);
    }
}
