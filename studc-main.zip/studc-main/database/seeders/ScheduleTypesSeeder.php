<?php

namespace Database\Seeders;

use App\Models\ScheduleTypes;
use Illuminate\Database\Seeder;

class ScheduleTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $scheduleTypes = [
            [
                'title' => 'Лекция'
            ],
            [
                'title' => 'Практика'
            ]
        ];

        foreach ($scheduleTypes as &$type) {
            $type['created_at'] = now();
            $type['updated_at'] = now();
        }

        ScheduleTypes::insert($scheduleTypes);
    }
}
