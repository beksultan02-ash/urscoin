<?php

namespace Database\Seeders;

use App\Models\StudOrg;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class StudOrgSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $orgs = [
            [
                'title' => 'Enactus IITU',
                'title_desc' => 'Быстрый заработок при участии в волонтерстве вместе с enactus',
                'salary_amount' => '6000',
                'salary_currency_id' => 1,
                'location' => 'Басенова 123',
                'description' => '«ENACTUS IITU» — это часть глобальной организации «Enactus KAZAKHSTAN». Это международная организация, миссия которой заключается в том, чтобы улучшить жизнь людей через предпринимательское действие. В ENACTUS IITU студенты имеют возможность научиться работать в команде, применять на практике теоретические знания.',
                'photo' => env('APP_URL') . ('/orgs/enactus_group.png'),
                'email' => 'artykbaev97@gmail.com'
            ]
        ];

        foreach ($orgs as &$org) {
            $org['created_at'] = now();
            $org['updated_at'] = now();
        }

        StudOrg::insert($orgs);
    }
}
