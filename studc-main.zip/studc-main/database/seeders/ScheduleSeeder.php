<?php

namespace Database\Seeders;

use App\Models\Schedule;
use Illuminate\Database\Seeder;

class ScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $schedules = [
            [
                'lesson' => 'Веб разработка',
                'type_id' => 1,
                'time_of_the_lesson' => '8:00 - 10:00',
                'day_of_week' => 1
            ],
            [
                'lesson' => 'История',
                'type_id' => 2,
                'time_of_the_lesson' => '12:00 - 14:00',
                'day_of_week' => 1
            ],
            [
                'lesson' => 'UI/UX дизайн',
                'type_id' => 2,
                'time_of_the_lesson' => '15:00 - 17:00',
                'day_of_week' => 1
            ],

            [
                'lesson' => 'Математика',
                'type_id' => 2,
                'time_of_the_lesson' => '10:00 - 12:00',
                'day_of_week' => 3
            ],
            [
                'lesson' => 'Философия',
                'type_id' => 1,
                'time_of_the_lesson' => '14:00 - 16:00',
                'day_of_week' => 3
            ],

            [
                'lesson' => 'Философия',
                'type_id' => 2,
                'time_of_the_lesson' => '9:00 - 11:00',
                'day_of_week' => 4
            ],
            [
                'lesson' => 'История',
                'type_id' => 1,
                'time_of_the_lesson' => '15:00 - 17:00',
                'day_of_week' => 4
            ],
            [
                'lesson' => 'Веб - разработка',
                'type_id' => 2,
                'time_of_the_lesson' => '12:00 - 14:00',
                'day_of_week' => 4
            ],

            [
                'lesson' => 'Математика',
                'type_id' => 1,
                'time_of_the_lesson' => '11:00 - 13:00',
                'day_of_week' => 5
            ],
            [
                'lesson' => 'Веб-разработка',
                'type_id' => 2,
                'time_of_the_lesson' => '14:00 - 16:00',
                'day_of_week' => 5
            ],

        ];
        foreach ($schedules as &$schedule) {
            $schedule['created_at'] = now();
            $schedule['updated_at'] = now();
        }
        Schedule::insert($schedules);
    }
}
