<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Currency extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
    protected $fillable = [
        'title'
    ];

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function orgs(): HasMany
    {
        return $this->hasMany(StudOrg::class);
    }
}
