<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Notifications\Notifiable;

class EntriesCode extends Model
{
    use HasFactory;
    use Notifiable;

    protected $table = 'users_entrances_code';

    protected $fillable = [
        'user_id',
        'email',
        'code',
        'used',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
