<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use HasApiTokens;
    use HasFactory;
    use Notifiable;

    protected $with = ['retakes'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'surname',
        'patronymic',
        'birthday',
        'group',
        'wallet_address',
        'amount',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier(): mixed
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims(): array
    {
        return [];
    }

    public function entriesCode(): HasMany
    {
        return $this->hasMany(EntriesCode::class);
    }

    public function paymentApplicationLists(): BelongsToMany
    {
        return $this->belongsToMany(StudOrg::class, 'payment_application_lists', 'user_id', 'stud_org_id')
            ->withPivot('is_approved')
            ->withTimestamps();
    }

    public function fromUserTransactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'from_user_id');
    }

    public function toUserTransactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'to_user_id');
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(static function ($user) {
            $randomString = Str::random(40);
            $walletAddress = "0x{$user->id}-{$randomString}";

            // Check if the wallet address is already taken
            $count = self::where('wallet_address', $walletAddress)->count();

            // If the wallet address is already taken, generate a new one
            while ($count > 0) {
                $randomString = Str::random(40);
                $walletAddress = "0x{$user->id}-{$randomString}";
                $count = self::where('wallet_address', $walletAddress)->count();
            }

            $user->wallet_address = $walletAddress;
        });
    }

    public function retakes(): HasMany
    {
        return $this->hasMany(StudentRetake::class);
    }
}
