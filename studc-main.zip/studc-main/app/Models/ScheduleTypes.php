<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ScheduleTypes extends Model
{
    use HasFactory;

    protected $table = 'schedule_types';
    protected $guarded = ['id'];
    public $timestamps = true;
    protected $fillable = [
        'title'
    ];

    public function schedule(): HasMany
    {
        return $this->hasMany(Schedule::class);
    }
}
