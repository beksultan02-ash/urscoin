<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Schedule extends Model
{
    use HasFactory;

    protected $table = 'schedule';
    protected $guarded = ['id'];
    public $timestamps = true;
    protected $fillable = [
        'lesson',
        'type_id',
        'time_of_the_lesson',
        'day_of_week',
    ];


    public function type(): BelongsTo
    {
        return $this->belongsTo(ScheduleTypes::class);
    }
}
