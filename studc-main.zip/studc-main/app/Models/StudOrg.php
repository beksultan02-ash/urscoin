<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;

class StudOrg extends Model
{
    use HasFactory;
    use Notifiable;
    use SoftDeletes;

    protected $with = ['currency'];

    protected $fillable = [
        'title',
        'title_desc',
        'salary_amount',
        'salary_currency_id',
        'location',
        'description',
        'photo',
        'email'
    ];

    public function currency(): BelongsTo
    {
        return $this->belongsTo(Currency::class, 'salary_currency_id');
    }

    public function paymentApplicationLists(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'payment_application_lists', 'stud_org_id', 'user_id')
            ->withPivot('is_approved')
            ->withTimestamps();
    }
}
