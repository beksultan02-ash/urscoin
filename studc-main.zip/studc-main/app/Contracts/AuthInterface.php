<?php

namespace App\Contracts;

use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Http\Requests\Auth\SendCodeRequest;
use Illuminate\Http\JsonResponse;

interface AuthInterface
{
    public function register(RegisterRequest $request): JsonResponse;

    public function login(LoginRequest $request): JsonResponse;

    public function resetPassword(ResetPasswordRequest $passwordRequest): JsonResponse;

    public function sendCode(SendCodeRequest $request): JsonResponse;

    public function refreshToken(): JsonResponse;
}
