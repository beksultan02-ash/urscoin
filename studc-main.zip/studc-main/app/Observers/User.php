<?php

namespace App\Observers;

use Illuminate\Support\Facades\Log;

class User
{
    public function created($model): void
    {
        $retakes = [
            [
                'title' => 'Веб-разработка',
                'payment_amount' => '1000',
                'expiration_date' => new \DateTime('2023-08-31 16:10:42'),
                'status' => 0,
                'user_id' => $model->id,
                'created_at' => '2023-05-11 16:10:42',
                'updated_at' => '2023-05-11 16:10:42'
            ],
            [
                'title' => 'Архитектура',
                'payment_amount' => '500',
                'expiration_date' => new \DateTime('2023-08-21 20:00:00'),
                'status' => 0,
                'user_id' => $model->id,
                'created_at' => '2023-05-11 16:10:42',
                'updated_at' => '2023-05-11 16:10:42'
            ]
        ];

        try {
            $model->retakes()->createMany($retakes);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }
}
