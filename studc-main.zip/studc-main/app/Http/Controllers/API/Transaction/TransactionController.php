<?php

namespace App\Http\Controllers\API\Transaction;

use App\Http\Controllers\Controller;
use App\Http\Requests\Transaction\CreateRequest;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();
        return response()->json([
            'from_transactions' => $user->fromUserTransactions,
            'to_transactions' => $user->toUserTransactions
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     * TODO оптимизировать и перенести в сервис.
     */
    public function store(CreateRequest $request): JsonResponse
    {
        $data = $request->validated();
        $to_user_id = User::where('wallet_address', $data['to_wallet_address'])->first()?->id;

        if (!$to_user_id) {
            return response()->json(['message' => 'Кошелек не существует!'], 422);
        }

        $user = auth()->user();

        if ($user->amount < $data['amount']) {
            return response()->json(['message' => 'Недостаточно средств!'], 422);
        }

        $data['to_user_id'] = $to_user_id;
        $data['from_user_id'] = $user->id;

        if ($data['from_user_id'] === $data['to_user_id']) {
            return response()->json(['message' => 'You can\'t send money to yourself'], 422);
        }

        try {
            DB::beginTransaction();
            $receipt = tap(Transaction::create($data), function ($receipt) use ($user) {
                $user->update(['amount' => $user->amount - $receipt->amount]);
                $receipt->update(['status' => 1]);
            });
            DB::commit();
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json(['message' => 'Something went wrong'], 500);
        }

        return response()->json(['message' => 'Created successfully', 'receipt' => $receipt], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Transaction $transaction)
    {
        //
    }
}
