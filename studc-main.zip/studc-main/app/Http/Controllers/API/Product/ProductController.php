<?php

namespace App\Http\Controllers\API\Product;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductCollection;
use App\Http\Resources\ProductResource;
use App\Models\Currency;
use App\Models\Product;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    public function getAllProducts(): ProductCollection
    {
        return ProductCollection::make(Product::with('currency')->get());
    }

    public function getProductById(Product $product): ProductResource
    {
        return ProductResource::make($product);
    }

    public function createProduct() //TODO создать реквест для создания
    {

    }

    public function updateProduct() //TODO создать реквест для обновления
    {

    }

    public function deleteProduct(Product $product): JsonResponse
    {
        $product->delete();
        return response()->json(['message' => 'Product deleted successfully!']);
    }

    public function getAllCurrencies() //TODO Перенести в свой контроллер, сейчас так впадлу на самом деле..
    {
        return Currency::all();
    }
}
