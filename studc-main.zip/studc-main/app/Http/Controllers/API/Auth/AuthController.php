<?php

namespace App\Http\Controllers\API\Auth;

use App\Contracts\AuthInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Http\Requests\Auth\SendCodeRequest;
use App\Models\EntriesCode;
use App\Models\User;
use App\Notifications\NewCodeNotification;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller implements AuthInterface
{
    //TODO Make a auth service and move all logic to it, in controller should not be anything except request validation and response

    public function register(RegisterRequest $request): JsonResponse
    {
        $data = $request->validated();
        $check = $this->checkCode($data['email'], $data['code']);

        if ($check !== true) {
            return $check;
        }

        $data['password'] = bcrypt($data['password']);
        $user = User::create($data);

        return response()->json([
            'message' => 'User created successfully',
            'user' => $user
        ], 201);
    }

    public function login(LoginRequest $request): JsonResponse
    {
        $data = $request->validated();


        if (!Hash::check($data['password'], User::where('email', $data['email'])->first()->password)) {
            return response()->json([
                'message' => 'Invalid credentials'
            ], 401);
        }

        $check = $this->checkCode($data['email'], $data['code']);

        if ($check !== true) {
            return $check;
        }

        $credentials = $request->only(['email', 'password']);
        $token = $this->respondWithToken(auth()->attempt($credentials));

        return response()->json([
            'message' => 'User logged in successfully',
            'token' => $token
        ]);
    }

    public function resetPassword(ResetPasswordRequest $passwordRequest): JsonResponse
    {
        $data = $passwordRequest->validated();
        $check = $this->checkCode($data['email'], $data['code']);

        if ($check !== true) {
            return $check;
        }

        $user = User::where('email', $data['email'])->first();
        $user->password = bcrypt($data['password']);
        $user->save();

        return response()->json([
            'message' => 'Password reset successfully'
        ]);
    }

    private function createEntryCode($data, $state)
    {
        return EntriesCode::create([
            'email' => $data['email'],
            'code' => $state ? Str::upper(Str::random(6)) : '123456',
        ]);
    }

    public function sendCode(SendCodeRequest $request): JsonResponse
    {
        $data = $request->validated();
        $state = env('APP_ENV') === 'development';
        $code = $this->createEntryCode($data, $state);

        if ($state) {
            $code->notify(new NewCodeNotification($code->code)); // TODO make an event please, what with this kolxoz?
        }
        return response()->json([
            'message' => 'Code sent successfully',
            'code' => $code
        ]);
    }

    private function checkCode($email, $code): JsonResponse|bool
    {
        $entryCode = EntriesCode::where('code', $code)
            ->where('email', $email)
            ->where('used', 0)
            ->first();

        if (!$entryCode) {
            return response()->json('This user has not such code.Or code was used', 403);
        }

        if ($entryCode->created_at->diffInMinutes(now()) > 5) {
            return response()->json('This code was out of time', 403);
        }

        $entryCode->used = 1;
        $entryCode->save();

        return true;
    }

    public function refreshToken(): JsonResponse
    {
        $token = $this->respondWithToken(auth()->refresh());
        return response()->json([
            'message' => 'Token refreshed successfully',
            'token' => $token
        ]);
    }

    /**
     * Get the token array structure.
     *
     * @param string $token
     *
     * @return JsonResponse
     */
    protected function respondWithToken(string $token): JsonResponse
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }
}
