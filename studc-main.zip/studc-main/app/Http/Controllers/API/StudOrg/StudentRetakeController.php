<?php

namespace App\Http\Controllers\API\StudOrg;

use App\Http\Controllers\Controller;
use App\Http\Requests\StudOrgs\Retakes\StudentRetakeCreateRequest;
use App\Http\Requests\StudOrgs\Retakes\StudentRetakeUpdateRequest;
use App\Models\StudentRetake;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StudentRetakeController extends Controller
{
    public function index(): JsonResponse
    {
        $user = auth()->user();

        return response()->json([
            'retakes' => $user->retakes->where('status', false)->values()
        ]);
    }

    public function store(StudentRetakeCreateRequest $request): JsonResponse
    {
        $data = $request->validated();

        $retake = StudentRetake::create($data);

        return response()->json([
            'message' => 'Stored successfully',
            'retake' => $retake
        ]);
    }

    public function update(StudentRetake $retake, StudentRetakeUpdateRequest $request): JsonResponse
    {
        $data = $request->validated();

        $retake->update($data);

        return response()->json([
            'message' => 'Updated successfully'
        ]);
    }

    public function delete(StudentRetake $retake): JsonResponse
    {
        $retake->delete();

        return response()->json([
            'message' => 'Deleted successfully'
        ]);
    }

    public function payRetake(StudentRetake $retake): JsonResponse
    {
        $user = auth()->user();

        if ($user->id !== $retake->user_id) {
            $message = 'You can\'t pay for this retake!';
        } elseif ($retake->status) {
            $message = 'Already paid!';
        } elseif ($user->amount < $retake->payment_amount) {
            $message = 'Недостаточно средств!';
        } else {
            DB::beginTransaction();

            try {
                $user->amount -= $retake->payment_amount;
                $user->save();

                $retake->status = true;
                $retake->save();

                DB::commit();
                $message = 'Paid successfully';
            } catch (\Exception $exception) {
                DB::rollBack();
                Log::error($exception->getMessage());
                return response()->json(
                    [
                        'message' => 'Something went wrong and Payment was failed.'
                    ], 500);
            }
        }

        return response()->json(['message' => $message], $message === 'Paid successfully' ? 200 : 422);
    }

}
