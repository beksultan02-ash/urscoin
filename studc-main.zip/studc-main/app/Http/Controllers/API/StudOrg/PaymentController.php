<?php

namespace App\Http\Controllers\API\StudOrg;

use App\Http\Controllers\Controller;
use App\Http\Requests\StudOrgs\Payments\CreatePaymentRequest;
use App\Http\Resources\PaymentCollection;
use App\Models\Payment;
use App\Models\StudOrg;
use App\Models\User;
use App\Notifications\PaymentApplication;
use Illuminate\Http\JsonResponse;

class PaymentController extends Controller
{
    public function getByAddress(string $address): JsonResponse
    {
        $payments = Payment::where('address', $address)->get();
        return response()->json(PaymentCollection::make($payments));
    }

    public function create(CreatePaymentRequest $request): JsonResponse
    {
        $data = $request->validated();
        $result = Payment::create($data) ? 'Payment successfully created!' : 'Error while creating payment!';
        $address = $data['address'];

        $users = User::whereHas('paymentApplicationLists', static function ($query) use ($address) {
            $query->where('wallet_address', $address);
        })->get();

        foreach ($users as $user) {
            $user->paymentApplicationLists()->detach();
        }

        return response()->json(['message' => $result]);
    }

    public function applyToPayment(StudOrg $studOrg): JsonResponse
    {
        $user = auth()->user();

        try {
            $user->paymentApplicationLists()->attach($studOrg->id);
        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()]);
        }
        $studOrg->notify(new PaymentApplication($user));
        return response()->json(['message' => 'Successfully applied to payment!']);
    }

    public function getApplicationsToPayment(): JsonResponse
    {
        $user = auth()->user();
        $applications = $user->paymentApplicationLists()->get();
        $pivots = [];
        foreach ($applications as $application) {
            $pivots[] = $application->pivot;
        }
        return response()->json($pivots);
    }
}
