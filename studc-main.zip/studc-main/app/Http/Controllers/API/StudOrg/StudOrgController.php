<?php

namespace App\Http\Controllers\API\StudOrg;

use App\Http\Controllers\Controller;
use App\Models\StudOrg;
use Illuminate\Http\JsonResponse;

class StudOrgController extends Controller
{
    public function getAllOrgs(): JsonResponse
    {
        return response()->json(StudOrg::all());
    }

    public function getOrgById(StudOrg $org): JsonResponse
    {
        return response()->json($org);
    }

    public function createOrg() //TODO в случае необходимости сделать
    {

    }

    public function updateOrg() //TODO в случае необходимости сделать
    {

    }

    public function deleteOrg() // TODO в случае необходимости сделать
    {

    }
}
