<?php

namespace App\Http\Controllers\API\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\UpdateProfileRequest;
use App\Http\Resources\ProfileCollection;
use App\Http\Resources\ProfileResource;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function getProfile(): JsonResponse
    {
        $user = auth()->user();
        return response()->json(ProfileResource::make($user));
    }

    public function updateProfile(UpdateProfileRequest $request): JsonResponse
    {
        $user = auth()->user();
        $data = $request->validated();
        $message = $user?->update($data) ? 'Profile successfully updated!' : 'Error while updating profile!';
        return response()->json(['message' => $message]);
    }
}
