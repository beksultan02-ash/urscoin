<?php

namespace App\Http\Controllers\API\Schedule;

use App\Http\Controllers\Controller;
use App\Models\Schedule;
use App\Models\ScheduleTypes;
use Illuminate\Database\Eloquent\Collection;

class ScheduleController extends Controller
{
    public function getSchedule(): Collection
    {
        return Schedule::all();
    }

    public function getScheduleTypes(): Collection
    {
        return ScheduleTypes::all();
    }
}
