<?php

namespace App\Http\Controllers\Privacy;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;

class PrivacyController extends Controller
{
    public function show(): \Illuminate\Http\Response
    {
        $pdfPath = public_path('privacy.pdf');

        return Response::make(file_get_contents($pdfPath), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="privacy.pdf"',
        ]);
    }

}
