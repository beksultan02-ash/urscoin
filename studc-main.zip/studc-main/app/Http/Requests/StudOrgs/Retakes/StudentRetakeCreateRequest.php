<?php

namespace App\Http\Requests\StudOrgs\Retakes;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\ValidationException;

class StudentRetakeCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'payment_amount' => 'required|integer',
            'title' => 'required|string',
        ];
    }

    public function messages(): array
    {
        return [
            'payment_amount.required' => 'Payment amount is required',
            'payment_amount.integer' => 'Payment amount must be an integer',
            'title.required' => 'Title is required',
            'title.string' => 'Title must be a string',
        ];
    }

    public function attributes(): array
    {
        return [
            'payment_amount' => 'payment amount',
            'title' => 'title',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        $response = response()->json([
            'message' => 'The given data was invalid',
            'errors' => $validator->errors(),
        ], 422);

        throw new ValidationException($validator, $response);
    }
}
