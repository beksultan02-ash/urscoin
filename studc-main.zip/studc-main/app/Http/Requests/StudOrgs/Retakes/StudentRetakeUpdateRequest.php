<?php

namespace App\Http\Requests\StudOrgs\Retakes;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class StudentRetakeUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'payment_amount' => 'integer',
            'title' => 'string',
            'expiration_date' => 'date',
            'status' => 'boolean',
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        return response([
            'message' => 'The given data was invalid',
        ], 422);
    }
}
