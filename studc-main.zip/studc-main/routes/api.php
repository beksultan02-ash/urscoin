<?php

use App\Http\Controllers\API\Auth\AuthController;
use App\Http\Controllers\API\Product\ProductController;
use App\Http\Controllers\API\StudOrg\StudentRetakeController;
use App\Http\Controllers\API\Transaction\TransactionController;
use App\Http\Controllers\API\User\ProfileController;
use App\Http\Controllers\API\Schedule\ScheduleController;
use App\Http\Controllers\API\StudOrg\PaymentController;
use App\Http\Controllers\API\StudOrg\StudOrgController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'schedule'], static function () { //TODO Защитить роуты, добавить middleware?
    Route::get('get-all', [ScheduleController::class, 'getSchedule']);
    Route::get('get-types', [ScheduleController::class, 'getScheduleTypes']);
});


Route::group(['prefix' => 'auth'], static function () {
    Route::post('login', [AuthController::class, 'login']);
    Route::post('register', [AuthController::class, 'register']);
    Route::post('reset-password', [AuthController::class, 'resetPassword']);
    Route::get('refresh-token', [AuthController::class, 'refreshToken']);
    Route::post('send-code', [AuthController::class, 'sendCode']);
    Route::group(['prefix' => 'profile', 'middleware' => 'auth'], static function () {
        Route::get('get', [ProfileController::class, 'getProfile']);
        Route::patch('update', [ProfileController::class, 'updateProfile']);
    });
});

//TODO дополнить create и update роутами..
Route::group(['prefix' => 'products'], static function () { // TODO Добавь в логику 'middleware' => 'auth' как будет готово, а пока так.
    Route::get('get-all', [ProductController::class, 'getAllProducts']);
    Route::get('get-by-id/{product}', [ProductController::class, 'getProductById']);
    Route::delete('delete/{product}', [ProductController::class, 'deleteProduct']);
    Route::get('get-all-currencies', [ProductController::class, 'getAllCurrencies']);
});

Route::group(['prefix' => 'orgs'], static function () {
    Route::get('get-all', [StudOrgController::class, 'getAllOrgs']);
    Route::get('get-by-id/{org}', [StudOrgController::class, 'getAllOrgs']);
    Route::group(['prefix' => 'payments'], static function () {
        Route::get('get-by-address/{address}', [PaymentController::class, 'getByAddress']);
        Route::post('create', [PaymentController::class, 'create']);
        Route::get('apply-to-payment/{studOrg}', [PaymentController::class, 'applyToPayment'])->middleware('auth');
        Route::get('get-applications-to-payment', [PaymentController::class, 'getApplicationsToPayment'])->middleware('auth');
    });
});

Route::group(['prefix' => 'transactions', 'middleware' => 'auth'], static function () {
    Route::get('get-all', [TransactionController::class, 'index']);
    Route::post('create', [TransactionController::class, 'store']);
});

Route::group(['prefix' => 'retakes', 'middleware' => 'auth'], static function () {
    Route::get('/', [StudentRetakeController::class, 'index']);
    Route::post('/pay/{retake}', [StudentRetakeController::class, 'payRetake']);
});
