//
//  BaseCoordinator.swift
//  Enactus
//
//  Created by Dinmukhamed on 19.04.2023.
//

import Foundation

class BaseCoordinator: Coordinator {
    
    var childCoordinators: [Coordinator] = []
    
    func start() {
        
    }
}
