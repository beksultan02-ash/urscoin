protocol ConfirmViewModelProtocol {
    var text: String {get}
}

struct ConfirmViewModel: ConfirmViewModelProtocol {
    var text: String
}
